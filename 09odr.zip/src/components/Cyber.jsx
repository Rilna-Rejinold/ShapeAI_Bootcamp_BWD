import React from "react";

function Cyber() {
  return (
    <div className="note">
      <h1>Python and Cyber Security</h1>
      <p>A basic python and cyber security bootcamp</p>
    </div>
  );
}

export default Cyber;
