import React from "react";
import Header from "./Header";
import Footer from "./Footer";
import Info from "./Info";
import Cyber from "./Cyber";
import DA from "./DA";
function App() {
  return (
    <div>
      <Header />
      <Footer />
      <Info />
      <Cyber />
      <DA />
    </div>
  );
}

export default App;
