import React from "react";

function Header() {
  return (
    <header>
      <h1>ShapeAI Bootcamps</h1>
    </header>
  );
}

export default Header;
