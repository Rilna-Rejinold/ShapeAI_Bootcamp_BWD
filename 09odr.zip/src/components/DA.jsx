import React from "react";

function DA() {
  return (
    <div className="note">
      <h1>Data Analytics with excel</h1>
      <p>A basic Data Analytics with excel bootcamp</p>
    </div>
  );
}

export default DA;
